# -*- coding: utf-8 -*-
import scrapy
import sys
from ..items import OpmItem
import re
import time
from scrapy.http import FormRequest, Request
from hall_infos import hall_infos
import logging
import copy

logging.basicConfig(filename='terminal.log', level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

reload(sys)
sys.setdefaultencoding('utf-8')


class TerminalSpider(scrapy.Spider):
    name = 'terminal'
    allowed_domains = ['114.242.119.194']

    def __init__(self, *args, **kwargs):
        super(TerminalSpider, self).__init__(*args, **kwargs)

        self.hall_infos = copy.deepcopy(hall_infos)
        self.temp_hall_infos = copy.deepcopy(hall_infos)
        self.parameter_name = ('proId', 'areaId', 'hallId')
        self.form_data_login = {
            'referer': 'index.php',
            'login': 'jinf',
            'cookietime': '2592000',
            'password': 'jinf',
            'submit': '马上登陆',
        }

    def start_requests(self):
        return [Request(url="http://114.242.119.194:9714/test.html", callback=self.post_login)]

    def post_login(self, response):
        return [FormRequest.from_response(
            response,
            headers=response.request.headers,
            formdata=self.form_data_login,
            callback=self.post_search_data,
        )]

    def post_search_data(self, response):
        '''
        for hall_info in self.hall_infos:
            post_data = dict(zip(self.parameter_name, hall_info))
            yield FormRequest(
                url='http://114.242.119.194:9714/infoplatform/hall/loadPrePareProData.action',
                formdata=post_data,
                callback=self.parse,
                meta=post_data,
            )
        '''
        hall_info = self.temp_hall_infos.pop()
        post_data = dict(zip(self.parameter_name, hall_info))
        yield FormRequest(
            url='http://114.242.119.194:9714/infoplatform/hall/loadPrePareProData.action',
            formdata=post_data,
            callback=self.parse,
            meta=post_data,
        )


    def parse(self, response):
        node_list = response.xpath("//tr[@bgcolor='#FFFFFF']")
        post_data = response.meta
        logging.info('parse post data: {}'.format(post_data))
        if not node_list:
            return
        for node in node_list:
            item = OpmItem()

            proId = post_data['proId']
            areaId = post_data['areaId']
            hallId = post_data['hallId']

            proName = node.xpath("//select[@id='proId']/option[@selected='selected']/text()").extract()[0].encode('utf-8')
            areaName = node.xpath("//select[@id='areaId']/option[@selected='selected']/text()").extract()[0].encode('utf-8')
            hallName = node.xpath("//select[@id='hallId']/option[@selected='selected']/text()").extract()[0].encode('utf-8')

            terminal_id = node.xpath("./td[2]/strong/text()").extract()
            terminal_sale = node.xpath("./td[3]/text()").extract()
            terminal_sale_percent = node.xpath("./td[4]/text()").extract()
            terminal_winning = node.xpath("./td[5]/text()").extract()
            terminal_redemption_percent = node.xpath("./td[6]/text()").extract()
            terminal_single_bet = node.xpath("./td[7]/text()").extract()

            item['proId'] = proId
            item['areaId'] = areaId
            item['hallId'] = hallId
            item['proName'] = proName
            item['areaName'] = areaName
            item['hallName'] = hallName
            item['terminal_id'] = terminal_id[0].encode('utf-8').replace('\t', '').replace(' ', '')
            item['terminal_sale'] = terminal_sale[0].encode('utf-8').replace('\t', '').replace(' ', '')
            item['terminal_sale_percent'] = terminal_sale_percent[0].encode('utf-8').replace('\t', '').replace(' ', '')
            item['terminal_winning'] = terminal_winning[0].encode('utf-8').replace('\t', '').replace(' ', '')
            item['terminal_redemption_percent'] = terminal_redemption_percent[0].encode('utf-8').replace('\t', '').replace(' ', '')
            item['terminal_single_bet'] = terminal_single_bet[0].encode('utf-8').replace('\t', '').replace(' ', '')

            logging.info('item data: {}'.format(item))
            yield item

            if self.temp_hall_infos:
                hall_info = self.temp_hall_infos.pop()
                post_data = dict(zip(self.parameter_name, hall_info))
                yield FormRequest(
                    url='http://114.242.119.194:9714/infoplatform/hall/loadPrePareProData.action',
                    formdata=post_data,
                    callback=self.parse,
                    meta=post_data,
                )